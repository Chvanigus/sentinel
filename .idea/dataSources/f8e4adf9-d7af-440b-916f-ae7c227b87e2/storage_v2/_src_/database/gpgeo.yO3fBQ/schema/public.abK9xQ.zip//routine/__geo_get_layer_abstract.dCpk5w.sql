create function __geo_get_layer_abstract(fieldid_ integer)
    returns TABLE(abstract text, "group" character varying, "time" double precision, agro integer, year text, layer character varying, day text, month text, monthday text)
    language plpgsql
as
$$
DECLARE agroid_ integer;
BEGIN

	if fieldid_ is NULL then
		RETURN QUERY
		SELECT 
			 to_char(date, 'DD.MM.YYYY') || ' ' || resolution::text || 'м' || '(' || satellite || ')' as abstract 
			,set as group
			,extract(epoch from date) as time
			,agroid as agro
			,to_char(date, 'YYYY') as year
			,name as layer
			,to_char(date, 'DD') as day
			,to_char(date, 'MM') as month
			,to_char(date, 'MM.DD') as monthday
		
		FROM "Layer"
		WHERE fieldid is NULL
		ORDER BY agroid, date, name;
	else	
		
		SELECT agroid INTO agroid_ FROM "Field" WHERE id = fieldid_ LIMIT 1;
		
		RETURN QUERY
		SELECT 
			 to_char(date, 'DD.MM.YYYY') as abstract 
			,set as group
			,extract(epoch from date) as time
			,agroid as agro
			,to_char(date, 'YYYY') as year
			,name as layer
			,to_char(date, 'DD') as day
			,to_char(date, 'MM') as month
			,to_char(date, 'MM.DD') as monthday
		
		FROM "Layer"
		WHERE fieldid = fieldid_ OR (fieldid is NULL AND isgrouplayer = FALSE AND agroid = agroid_)
		ORDER BY agroid, date, name;
	end if;	

END;
$$;

alter function __geo_get_layer_abstract(integer) owner to geoadmin;

