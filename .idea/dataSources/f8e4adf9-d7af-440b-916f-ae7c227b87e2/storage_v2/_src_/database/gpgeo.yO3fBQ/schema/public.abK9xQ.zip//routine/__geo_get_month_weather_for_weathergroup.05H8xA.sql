create function __geo_get_month_weather_for_weathergroup(weathergroupid_ integer, year_ integer, month_ integer)
    returns TABLE("WeatherData_date" date, "WeatherData_temperature_avg" double precision, "WeatherData_temperature_min" real, "WeatherData_temperature_max" real, "WeatherData_rain_max" real, "WeatherData_temperature_dewpoint" real)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select  wd1_."WeatherData_date" as "WeatherData_date", 	   
			wd1_."WeatherData_temperature_avg" as "WeatherData_temperature_avg",
			wd1_."WeatherData_temperature_min" as "WeatherData_temperature_min",
			wd1_."WeatherData_temperature_max" as "WeatherData_temperature_max",
			wd1_."WeatherData_rain_max" as "WeatherData_rain_max",
			wd2_."WeatherData_temperature_dewpoint" as "WeatherData_temperature_dewpoint"

	from
	(
		(select DATE(wd.datetime) as "WeatherData_date", 	   
				avg(wd.temperature) as "WeatherData_temperature_avg",
				min(wd.temperature) as "WeatherData_temperature_min",
				max(wd.temperature) as "WeatherData_temperature_max",
				sum(wd.rain) as "WeatherData_rain_max"
		from "WeatherData" as wd 
				inner join "WeatherStation" ws on  (ws.id = wd.weatherstationid 
													AND ws.weathergroupid = weathergroupid_ 
													AND EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_ 
													AND EXTRACT(MONTH FROM wd.datetime)::INTEGER = month_)	
		group by DATE(wd.datetime)
		order by DATE(wd.datetime) DESC) as wd1_

		left outer join 

		(select DATE(wd.datetime) as "WeatherData_date"
		      ,sum(wd.dewpoint) as "WeatherData_temperature_dewpoint"
		from "WeatherData" as wd inner join "WeatherStation" ws 
				on (ws.id = wd.weatherstationid 
				AND ws.weathergroupid = weathergroupid_ 
				AND EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_ 
				AND EXTRACT(MONTH FROM wd.datetime)::INTEGER = month_ 
				AND wd.temperature <= wd.dewpoint)		     
		group by DATE(wd.datetime)
		order by DATE(wd.datetime) DESC) as wd2_
		
		on wd1_."WeatherData_date" = wd2_."WeatherData_date"
	)
	order by wd1_."WeatherData_date" DESC;
END;
$$;

alter function __geo_get_month_weather_for_weathergroup(integer, integer, integer) owner to geoadmin;

