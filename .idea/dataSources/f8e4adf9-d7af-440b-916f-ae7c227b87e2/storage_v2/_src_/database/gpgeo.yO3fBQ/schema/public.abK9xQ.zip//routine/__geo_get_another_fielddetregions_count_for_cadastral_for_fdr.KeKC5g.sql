create function __geo_get_another_fielddetregions_count_for_cadastral_for_fdr(fielddetachedregionid_ bigint, cadastralid_ bigint) returns bigint
    language sql
as
$$   
select count(distinct fdr.id)
from "DetachedRegion" dr inner join 
		"FieldDetachedRegion" fdr on (fdr.detachedregionid = dr.id AND dr.cadastralid = cadastralid_)			 
where fdr.id <> fielddetachedregionid_;

$$;

alter function __geo_get_another_fielddetregions_count_for_cadastral_for_fdr(bigint, bigint) owner to postgres;

