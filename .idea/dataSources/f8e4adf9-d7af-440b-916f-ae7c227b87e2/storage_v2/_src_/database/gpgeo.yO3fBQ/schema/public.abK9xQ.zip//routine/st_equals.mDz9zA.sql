create function st_equals(geom1 geometry, geom2 geometry) returns boolean
    immutable
    language sql
as
$$SELECT $1 ~= $2 AND _ST_Equals($1,$2)$$;

comment on function st_equals(geometry, geometry) is 'args: A, B - Returns true if the given geometries represent the same geometry. Directionality is ignored.';

alter function st_equals(geometry, geometry) owner to postgres;

