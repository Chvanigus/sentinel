create function __geo_get_cadastrals_with_detached_regions_for_field(fieldid_ bigint)
    returns TABLE("Cadastral_id" bigint, "Cadastral_number" character varying, "Cadastral_officialarea" real, "Cadastral_additional" text, "DetachedRegion_id" bigint, "DetachedRegion_number" character varying, "DetachedRegion_area" real, "DetachedRegion_additional" text, "DetachedRegion_cadastralid" bigint)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	SELECT  c.id as "Cadastral_id",
			c.number as "Cadastral_number",
			c.officialarea as "Cadastral_officialarea",
			c.additional as "Cadastral_additional",
		
			dr.id as "DetachedRegion_id",
			dr.number as "DetachedRegion_number",
			dr.area as "DetachedRegion_area",
			dr.additional as "DetachedRegion_additional",
			dr.cadastralid as "DetachedRegion_cadastralid"

	From "DetachedRegion" dr inner join "FieldDetachedRegion" fdr on dr.id = fdr.detachedregionid And fdr.fieldid = fieldid_
					   inner join "Cadastral" c on c.id = dr.cadastralid
	ORDER BY c.id, dr.id;
END;
$$;

alter function __geo_get_cadastrals_with_detached_regions_for_field(bigint) owner to postgres;

