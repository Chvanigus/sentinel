create function __geo_get_another_fields_for_detachedregion_for_field(fieldid_ bigint, detachedregionid_ bigint)
    returns TABLE("Field_id" bigint, "Field_name" character varying, "Field_agroid" integer)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select  distinct f.id as "Field_id",
			f.name as "Field_name", 
			f.agroid as "Field_agroid"
	from "Field" f inner join 
	     "FieldDetachedRegion" fdr 
	     on f.id = fdr.fieldid AND fdr.detachedregionid = detachedregionid_
	where f.id <> fieldid_
	order by f.agroid, f.name;
END;
$$;

alter function __geo_get_another_fields_for_detachedregion_for_field(bigint, bigint) owner to postgres;

