create function st_astext(text) returns text
    immutable
    strict
    language sql
as
$$ SELECT ST_AsText($1::geometry);  $$;

alter function st_astext(text) owner to postgres;

