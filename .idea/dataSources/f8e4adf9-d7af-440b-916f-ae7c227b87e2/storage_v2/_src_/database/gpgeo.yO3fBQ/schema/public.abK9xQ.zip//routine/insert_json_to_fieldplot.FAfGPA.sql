create function insert_json_to_fieldplot(plotgeometry_ text) returns integer
    language plpgsql
as
$$ 
DECLARE
fieldplot_id integer;
BEGIN
INSERT INTO public.fieldplot(plotgeometry) VALUES (ST_GeomFromGeoJSON(plotgeometry_))
RETURNING id into fieldplot_id;
RETURN fieldplot_id;
END;
$$;

alter function insert_json_to_fieldplot(text) owner to geoadmin;

