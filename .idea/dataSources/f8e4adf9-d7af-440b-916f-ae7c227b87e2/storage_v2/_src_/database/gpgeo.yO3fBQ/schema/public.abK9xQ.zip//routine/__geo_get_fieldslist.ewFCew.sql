create function __geo_get_fieldslist(yieldyear_ integer)
    returns TABLE("Field_agroid" integer, "Field_id" bigint, "Field_name" character varying, "FieldCrop_id" bigint, "FieldCrop_accountcroparea" real, "FieldCrop_yieldfact" real, "FieldCrop_cropid" integer)
    language plpgsql
as
$$
BEGIN
   RETURN QUERY
   
	select   f.agroid as "Field_agroid" 
			,f.id as "Field_id"
			,f.name as "Field_name"		
			,fc.id as "FieldCrop_id"	
			,fc.accountcroparea as "FieldCrop_accountcroparea"
			,fc.yieldfact as "FieldCrop_yieldfact"
			,fc.cropid as "FieldCrop_cropid"
			
	from 	"Field" f 
			inner join "FieldCrop" fc on (fc.fieldid = f.id AND fc.yieldyear = yieldyear_)
					
	order by f.agroid, fc.cropid, cast(NULLIF(regexp_replace(f.name, E'\\D', '', 'g'), '') AS integer);

END;
$$;

alter function __geo_get_fieldslist(integer) owner to postgres;

