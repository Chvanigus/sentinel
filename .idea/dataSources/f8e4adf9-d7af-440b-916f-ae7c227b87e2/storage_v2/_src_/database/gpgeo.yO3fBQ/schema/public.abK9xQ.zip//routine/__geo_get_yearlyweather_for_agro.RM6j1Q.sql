create function __geo_get_yearlyweather_for_agro(agroid_ integer, year_ integer)
    returns TABLE("WeatherData_weathergroupid" integer, "WeatherData_month" integer, "WeatherData_temperature_avg" numeric, "WeatherData_temperature_min" real, "WeatherData_temperature_max" real, "WeatherGroup_name" character varying, "WeatherData_rain_sum" numeric)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select  t1._weathergroupid as "WeatherData_weathergroupid",
			t1._month as "WeatherData_month",
			round(t1._temperature_avg::numeric, 1) as "WeatherData_temperature_avg",
			t1._temperature_min "WeatherData_temperature_min",
			t1._temperature_max as "WeatherData_temperature_max",
			t1._name as "WeatherGroup_name",
			round(t1._rain_sum::numeric, 1) as "WeatherData_rain_sum"
	from
		(select wg.id as "_weathergroupid",
				EXTRACT(MONTH FROM wd.datetime)::INTEGER as "_month",
				avg(wd.temperature) as "_temperature_avg",
				min(wd.temperature) as "_temperature_min",
				max(wd.temperature) as "_temperature_max",
				wg.shortname as "_name",
				sum(wd.rain) as "_rain_sum"
		from "WeatherData" as wd 
				inner join ("WeatherStation" ws 
								inner join ("WeatherGroup" wg inner join "WeatherGroupAgro" wga on (wg.id = wga.weathergroupid and wga.agroid = agroid_)) 
								on ws.weathergroupid = wg.id) 
				on (ws.id = wd.weatherstationid AND EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_)		
		group by "_weathergroupid", "_name", "_month") as t1	
	order by t1._weathergroupid, t1._month;
END;
$$;

alter function __geo_get_yearlyweather_for_agro(integer, integer) owner to geoadmin;

