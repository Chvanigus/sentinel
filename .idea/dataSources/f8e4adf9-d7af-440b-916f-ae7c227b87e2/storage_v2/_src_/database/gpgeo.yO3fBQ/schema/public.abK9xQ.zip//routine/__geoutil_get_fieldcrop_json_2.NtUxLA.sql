create function __geoutil_get_fieldcrop_json_2(agroid_ integer, year_ integer, fieldgroupid_ integer) returns text
    language plpgsql
as
$$ 
  
BEGIN

   IF fieldgroupid_ IS NULL THEN
   return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		   END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
	    , ga.geometry
		, row_to_json(row(f.name, null, prop.sum_crop_area, prop."FieldGroup", ga."centrX", ga."centrY", f.name || '|' || prop.sum_crop_area, null, null, null, null)::"__geoUtil_fieldCropJsonProp") as properties

from
"Field" f 

inner join 

(select   f.id	as field_id	
		, ST_AsGeoJSON(fs.fieldgeometry)::json As geometry
		, round (cast (ST_Area(ST_Transform(fs.fieldgeometry, 32638)) / 10000 as numeric), 2) As "area_calc"
		, ST_X (ST_Centroid(fs.fieldgeometry)) As "centrX"
		, ST_Y (ST_Centroid(fs.fieldgeometry)) As "centrY"
from "Field" As f inner join "FieldShape" As fs on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_)) as ga on f.id = ga.field_id

inner join 

(select      f.id as field_id
			,sum(fc.accountcroparea) as sum_crop_area
			,ffg.fieldgroupid as "FieldGroup"
		
from "FieldCrop" fc inner join ("Field" f inner join "FieldFieldGroup" ffg on (f.id = ffg.fieldid AND ffg.year = year_) ) on (fc.fieldid = f.id AND f.agroid = agroid_ AND fc.yieldyear = year_)
Group by f.id, ffg.fieldgroupid) as prop on f.id = prop.field_id

) As ft) As ftc;


    ELSE return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		   END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
	    , ga.geometry
		, row_to_json(row(f.name, null, prop.sum_crop_area, prop."FieldGroup", ga."centrX", ga."centrY", f.name || '|' || prop.sum_crop_area, null, null, null, null)::"__geoUtil_fieldCropJsonProp") as properties

from
"Field" f 

inner join 

(select   f.id	as field_id	
		, ST_AsGeoJSON(fs.fieldgeometry)::json As geometry
		, round (cast (ST_Area(ST_Transform(fs.fieldgeometry, 32638)) / 10000 as numeric), 2) As "area_calc"
		, ST_X (ST_Centroid(fs.fieldgeometry)) As "centrX"
		, ST_Y (ST_Centroid(fs.fieldgeometry)) As "centrY"
from "Field" As f inner join "FieldShape" As fs on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_)) as ga on f.id = ga.field_id

inner join 

(select      f.id as field_id
			,sum(fc.accountcroparea) as sum_crop_area
			,ffg.fieldgroupid as "FieldGroup"
		
from "FieldCrop" fc inner join ("Field" f inner join "FieldFieldGroup" ffg on (f.id = ffg.fieldid AND ffg.year = year_ AND ffg.fieldgroupid = fieldgroupid_) ) on (fc.fieldid = f.id AND f.agroid = agroid_ AND fc.yieldyear = year_)
Group by f.id, ffg.fieldgroupid) as prop on f.id = prop.field_id

) As ft) As ftc;



   END IF;
   
 END  
 $$;

alter function __geoutil_get_fieldcrop_json_2(integer, integer, integer) owner to geoadmin;

