create function __geo_get_soilmoisturepoints_json(agroid_ integer, year_ integer, monthfrom_ integer, monthto_ integer) returns json
    language plpgsql
as
$$ 
  
BEGIN
    return array_to_json(array_agg(row))
from
(	select 	 ST_X (smsp.samplepoint) as lon
			,ST_Y (smsp.samplepoint) as lat
			,to_char(sms.date, 'DD.MM.YYYY') as date
			
	from "SoilMoistureSamplePoint" smsp inner join ("SoilMoistureSample" sms inner join "Field" f on (sms.fieldid = f.id and f.agroid = agroid_)) on sms.id = smsp.soilmoisturesampleid

	where EXTRACT(MONTH FROM sms.date)::INTEGER >= monthfrom_ 
			AND EXTRACT(MONTH FROM sms.date)::INTEGER <= monthto_ 
			AND EXTRACT(YEAR FROM sms.date)::INTEGER = year_
) as row;

END
$$;

alter function __geo_get_soilmoisturepoints_json(integer, integer, integer, integer) owner to postgres;

