create function st_length2d_spheroid(geometry, spheroid) returns double precision
    immutable
    strict
    language sql
as
$$ SELECT _postgis_deprecate('ST_Length2D_Spheroid', 'ST_Length2DSpheroid', '2.2.0');
    SELECT ST_Length2DSpheroid($1,$2);
  $$;

comment on function st_length2d_spheroid(geometry, spheroid) is 'args: a_linestring, a_spheroid - Calculates the 2D length of a linestring/multilinestring on an ellipsoid. This is useful if the coordinates of the geometry are in longitude/latitude and a length is desired without reprojection.';

alter function st_length2d_spheroid(geometry, spheroid) owner to postgres;

