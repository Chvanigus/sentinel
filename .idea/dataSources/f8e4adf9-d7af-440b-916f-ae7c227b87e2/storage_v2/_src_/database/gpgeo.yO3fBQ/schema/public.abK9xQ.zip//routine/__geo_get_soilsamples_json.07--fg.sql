create function __geo_get_soilsamples_json(agroid_ integer, year_ integer) returns json
    language plpgsql
as
$$   
BEGIN
   return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		  END)
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
		, ST_AsGeoJSON(fs1.fieldgeometry)::json As geometry
		, row_to_json(ffs) As properties		
		
from "FieldShape" fs1 inner join 

(select   f.id as "f"
		, f.name as "FieldNum"		
		
		, round (cast (ST_Area(ST_Transform(fs.fieldgeometry, 32638)) / 10000 as numeric), 2) As "AreaCalc"
		, ST_X (ST_Centroid(fs.fieldgeometry)) As "CentrX"
		, ST_Y (ST_Centroid(fs.fieldgeometry)) As "CentrY"
		
		, ss_n."n" as "N"		
		, ss_p."p" as "P"		
		, ss_k."k" as "K"		
		, ss_g."g" as "G"
		
		, ss_ys."Years" as "Years"
		

from 	"Field" f  	inner join "FieldShape" fs on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_)
					left outer join 
				
					(select   f.id as "fieldid"								
							, round((sum(ss.nitrogen) / count(ss.nitrogen))::numeric, 2) as "n"
					from "Field" f inner join "SoilSample" ss on (f.id = ss.fieldid AND f.agroid = agroid_ AND ss.nitrogen is not null)
					group by f.id
		
					) as ss_n on (f.id = ss_n.fieldid)
					
					left outer join 
				
					(select   f.id as "fieldid"								
							, round((sum(ss.phosphorus) / count(ss.phosphorus))::numeric, 2) as "p"
					from "Field" f inner join "SoilSample" ss on (f.id = ss.fieldid AND f.agroid = agroid_ AND ss.phosphorus is not null)
					group by f.id
		
					) as ss_p on (f.id = ss_p.fieldid)
					
					left outer join 
				
					(select   f.id as "fieldid"								
							, round((sum(ss.potassium) / count(ss.potassium))::numeric, 2) as "k"
					from "Field" f inner join "SoilSample" ss on (f.id = ss.fieldid AND f.agroid = agroid_ AND ss.potassium is not null)
					group by f.id
		
					) as ss_k on (f.id = ss_k.fieldid)
					
					left outer join 
				
					(select   f.id as "fieldid"								
							, round((sum(ss.humus) / count(ss.humus))::numeric, 2) as "g"
					from "Field" f inner join "SoilSample" ss on (f.id = ss.fieldid AND f.agroid = agroid_ AND ss.humus is not null)
					group by f.id
		
					) as ss_g on (f.id = ss_g.fieldid)
					
					left outer join 
					(select   f.id as fid
							, array_agg( distinct ss.year) as "Years"
					from "Field" f inner join "SoilSample" ss on (f.id = ss.fieldid AND f.agroid = agroid_)
					group by f.id
					) as ss_ys on (f.id = ss_ys.fid)
		
) as ffs
on fs1.fieldid = ffs.f and fs1.year = year_) As ft) As ftc;

END
$$;

alter function __geo_get_soilsamples_json(integer, integer) owner to postgres;

