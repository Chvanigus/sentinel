create function get_fieldplot_pointsarrayxy(fieldplotid_ integer)
    returns TABLE("0" double precision, "1" double precision)
    language sql
as
$$   
SELECT  
      ST_X ((dp).geom) As x,  ST_Y ((dp).geom) As y
FROM (SELECT ST_DumpPoints(plotgeometry) AS dp from public.fieldplot where id = fieldplotid_) As foo;

$$;

alter function get_fieldplot_pointsarrayxy(integer) owner to geoadmin;

