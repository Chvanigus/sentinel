create function __geo_get_fieldwork_years_for_field(fieldid_ bigint)
    returns TABLE(year integer)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
	select distinct EXTRACT(YEAR FROM date)::INTEGER as "year"
	from "FieldWork"
	where fieldid = fieldid_
order by year DESC;
END;
$$;

alter function __geo_get_fieldwork_years_for_field(bigint) owner to postgres;

