create function __geostl_get_boundpoints_wkt(year_ integer, proj_ integer, fieldid_ integer, agroid_ integer) returns text
    language plpgsql
as
$$
BEGIN

	IF fieldid_ IS NOT NULL THEN
		RETURN ST_AsText(ST_Envelope(ST_Extent(ST_Transform(fs.fieldgeometry, proj_))))
		FROM "FieldShape" fs
		WHERE fs.year = year_  AND fs.fieldid = fieldid_;

	ELSIF agroid_ IS NULL THEN
		RETURN ST_AsText(ST_Envelope(ST_Extent(ST_Transform(fs.fieldgeometry, proj_))))
		FROM "FieldShape" fs
		WHERE fs.year = year_; 
			
	ELSE
		RETURN ST_AsText(ST_Envelope(ST_Extent(ST_Transform(fs.fieldgeometry, proj_))))
		FROM "FieldShape" fs INNER JOIN "Field" f ON (f.id = fs.fieldid 
							      AND fs.year = year_
							      AND f.agroid = agroid_);
	END IF;	
END;
$$;

alter function __geostl_get_boundpoints_wkt(integer, integer, integer, integer) owner to geoadmin;

