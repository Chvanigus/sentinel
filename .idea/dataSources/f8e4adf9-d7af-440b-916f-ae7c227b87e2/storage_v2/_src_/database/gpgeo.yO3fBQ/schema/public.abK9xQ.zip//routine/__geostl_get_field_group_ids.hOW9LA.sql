create function __geostl_get_field_group_ids() returns SETOF integer
    language plpgsql
as
$$
BEGIN	
	RETURN QUERY 
	SELECT a.id FROM "Agro" as a;	
END;
$$;

alter function __geostl_get_field_group_ids() owner to geoadmin;

