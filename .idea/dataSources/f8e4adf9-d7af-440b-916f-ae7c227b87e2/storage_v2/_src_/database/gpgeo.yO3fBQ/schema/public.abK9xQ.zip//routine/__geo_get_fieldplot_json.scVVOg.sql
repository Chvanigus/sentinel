create function __geo_get_fieldplot_json(fieldplotid_ bigint) returns json
    language plpgsql
as
$$   
BEGIN
   return row_to_json(fc) 
	 FROM (SELECT 'Feature' As type
		, ST_AsGeoJSON(fp.plotgeometry)::json As geometry
	   FROM public."FieldPlot" As fp where fp.id = fieldplotid_ ) As fc;
END
$$;

alter function __geo_get_fieldplot_json(bigint) owner to postgres;

