create function __geo_get_cadastrals_with_detregions_with_owners_for_field(fieldid_ bigint)
    returns TABLE("Cadastral_id" bigint, "Cadastral_number" character varying, "Cadastral_officialarea" real, "Cadastral_arablearea" real, "Cadastral_additional" text, "DetachedRegion_id" bigint, "DetachedRegion_number" character varying, "DetachedRegion_area" real, "DetachedRegion_additional" text, "DetachedRegion_cadastralid" bigint, "DetachedRegion_officialarea" real, "DetachedRegion_sharenumerator" real, "DetachedRegion_sharedenominator" real, "FieldDetachedRegion_id" bigint, "FieldDetachedRegion_detachedregionid" bigint, "FieldDetachedRegion_fieldid" bigint, "Owner_id" integer, "Owner_name" character varying, "Owner_contactinformation" text, "Owner_cadastralownertypeid" integer, "Owner_color" character varying)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select  c.id as "Cadastral_id",
			c.number as "Cadastral_number",
			c.officialarea as "Cadastral_officialarea",
			c.arablearea as "Cadastral_arablearea",
			c.additional as "Cadastral_additional",
		
			dr.id as "DetachedRegion_id",
			dr.number as "DetachedRegion_number",
			dr.area as "DetachedRegion_area",
			dr.additional as "DetachedRegion_additional",
			dr.cadastralid as "DetachedRegion_cadastralid",
			dr.officialarea as "DetachedRegion_officialarea",
			dr.sharenumerator as "DetachedRegion_sharenumerator",
			dr.sharedenominator as "DetachedRegion_sharedenominator",
		
			fdr.id as "FieldDetachedRegion_id",
			fdr.detachedregionid as "FieldDetachedRegion_detachedregionid",
			fdr.fieldid as "FieldDetachedRegion_fieldid",
		
			o.id as "Owner_id",
			o.name as "Owner_name", 
			o.contactinformation as "Owner_contactinformation", 
			o.cadastralownertypeid as "Owner_cadastralownertypeid", 
			o.color as "Owner_color"
		
	from "FieldDetachedRegion" fdr inner join 
		("DetachedRegion" dr inner join
				"Cadastral" c on dr.cadastralid = c.id
						   left outer join
				("DetachedRegionOwner" dro inner join "Owner" o on o.id = dro.ownerid) on dr.id = dro.detachedregionid
		) 
		on (fdr.detachedregionid = dr.id AND fdr.fieldid = fieldid_)
	order by c.number, dr.number, o.id;
END;
$$;

alter function __geo_get_cadastrals_with_detregions_with_owners_for_field(bigint) owner to postgres;

