create function __geo_get_detreg_fullarea_for_agro(agroid_ integer) returns double precision
    language plpgsql
as
$$   
BEGIN
	return round(sum(dr.area)) 
	from 	"Field" f 
			inner join  ("FieldDetachedRegion" fdr 
						inner join  "DetachedRegion" dr on dr.id = fdr.detachedregionid) 
			on (f.id = fdr.fieldid AND f.agroid = agroid_);
END
$$;

alter function __geo_get_detreg_fullarea_for_agro(integer) owner to postgres;

