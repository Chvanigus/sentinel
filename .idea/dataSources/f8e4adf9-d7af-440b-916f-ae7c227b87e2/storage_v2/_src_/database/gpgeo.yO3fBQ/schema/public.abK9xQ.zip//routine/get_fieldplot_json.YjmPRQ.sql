create function get_fieldplot_json(fieldplotid_ integer) returns json
    language plpgsql
as
$$   
BEGIN
   return row_to_json(fc) 
	 FROM (SELECT 'Feature' As type
		, ST_AsGeoJSON(fp.plotgeometry)::json As geometry
	   FROM public.fieldplot As fp where fp.id = fieldplotid_ ) As fc;
END
$$;

alter function get_fieldplot_json(integer) owner to geoadmin;

