create function __geo_get_day_weather_for_weathergroup(weathergroupid_ integer, date_ date)
    returns TABLE("WeatherData_time" text, "WeatherData_temperature" real, "WeatherData_rain" real, "WeatherData_humidity" real, "WeatherData_barometer" real, "WeatherData_dewpoint" real, "WeatherData_windspeed" real, "WeatherData_windgust" real, "WeatherData_winddegrees" real, "WindDirection_direction" character varying)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
	select 	to_char( wd.datetime, 'HH24:MI') as "WeatherData_time", 	   
			wd.temperature as "WeatherData_temperature",	  
			wd.rain as "WeatherData_rain",
			wd.humidity as "WeatherData_humidity",
			wd.barometer as "WeatherData_barometer",
			wd.dewpoint as "WeatherData_dewpoint",
			wd.windspeed as "WeatherData_windspeed",
			wd.windgust as "WeatherData_windgust",
			wd.winddegrees as "WeatherData_winddegrees",
			wdr.directionmin as "WindDirection_direction"
			
	from "WeatherData" as wd inner join "WindDirection" as wdr on wdr.id = wd.winddirection
							 inner join "WeatherStation" as ws on (ws.id = wd.weatherstationid AND ws.weathergroupid = weathergroupid_ AND DATE(wd.datetime) = date_)
	order by wd.datetime::time DESC;
END;
$$;

alter function __geo_get_day_weather_for_weathergroup(integer, date) owner to geoadmin;

