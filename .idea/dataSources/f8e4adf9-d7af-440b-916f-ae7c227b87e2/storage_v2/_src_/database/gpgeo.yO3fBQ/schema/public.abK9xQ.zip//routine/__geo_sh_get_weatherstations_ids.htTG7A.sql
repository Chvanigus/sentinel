create function __geo_sh_get_weatherstations_ids() returns SETOF integer
    language sql
as
$$	
	select id 
	from "WeatherStation";
$$;

alter function __geo_sh_get_weatherstations_ids() owner to geoadmin;

