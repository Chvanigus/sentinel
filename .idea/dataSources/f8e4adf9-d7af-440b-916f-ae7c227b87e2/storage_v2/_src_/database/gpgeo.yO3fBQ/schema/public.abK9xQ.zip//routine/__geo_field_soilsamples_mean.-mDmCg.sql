create function __geo_field_soilsamples_mean(fieldid_ integer)
    returns TABLE("N" numeric, "P" numeric, "K" numeric, "G" numeric)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY
select 	     round (cast (n_sum/n_num as numeric), 2) As "N_mean"
			,round (cast (p_sum/p_num as numeric), 2) As "P_mean"
			,round (cast (k_sum/k_num as numeric), 2) As "K_mean"
			,round (cast (g_sum/g_num as numeric), 2) As "G_mean"			
from
(select 	
			count(nitrogen) as "n_num"
			,count(phosphorus) as "p_num"
			,count(potassium) as "k_num"
			,count(humus) as "g_num"
			,sum(nitrogen) as "n_sum"
			,sum(phosphorus) as "p_sum"
			,sum(potassium) as "k_sum"
			,sum(humus) as "g_sum"
from "SoilSample"  
where fieldid = fieldid_
) as f;

END;
$$;

alter function __geo_field_soilsamples_mean(integer) owner to postgres;

