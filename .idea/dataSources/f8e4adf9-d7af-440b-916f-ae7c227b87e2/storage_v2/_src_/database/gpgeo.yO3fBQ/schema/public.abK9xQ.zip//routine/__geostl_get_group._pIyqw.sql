create function __geostl_get_group(id_ integer) returns integer
    language plpgsql
as
$$
BEGIN	
	RETURN agroid FROM "Field" WHERE id = id_;		
END;
$$;

alter function __geostl_get_group(integer) owner to geoadmin;

