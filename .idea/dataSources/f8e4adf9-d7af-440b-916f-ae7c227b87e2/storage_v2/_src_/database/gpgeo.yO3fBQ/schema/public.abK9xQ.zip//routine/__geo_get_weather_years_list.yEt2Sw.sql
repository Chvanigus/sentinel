create function __geo_get_weather_years_list() returns SETOF integer
    language sql
as
$$	
	select distinct EXTRACT(YEAR FROM wd.datetime)::INTEGER as "year"
	from "WeatherData" as wd
	order by year;
$$;

alter function __geo_get_weather_years_list() owner to geoadmin;

