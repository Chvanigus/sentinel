create function st_intersects(geom1 geometry, geom2 geometry) returns boolean
    immutable
    language sql
as
$$SELECT $1 && $2 AND _ST_Intersects($1,$2)$$;

comment on function st_intersects(geometry, geometry) is 'args: geomA, geomB - Returns TRUE if the Geometries/Geography "spatially intersect in 2D" - (share any portion of space) and FALSE if they dont (they are Disjoint). For geography -- tolerance is 0.00001 meters (so any points that close are considered to intersect)';

alter function st_intersects(geometry, geometry) owner to postgres;

