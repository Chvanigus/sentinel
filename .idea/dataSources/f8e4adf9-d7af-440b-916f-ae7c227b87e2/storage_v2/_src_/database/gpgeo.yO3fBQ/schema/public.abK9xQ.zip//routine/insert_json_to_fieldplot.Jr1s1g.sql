create function insert_json_to_fieldplot(plotgeometry_ text, fieldplot_id integer) returns void
    language plpgsql
as
$$ 
BEGIN
INSERT INTO public.fieldplot(plotgeometry) VALUES (ST_GeomFromGeoJSON(plotgeometry_))
RETURNING id into fieldplot_id;
END;
$$;

alter function insert_json_to_fieldplot(text, integer) owner to geoadmin;

