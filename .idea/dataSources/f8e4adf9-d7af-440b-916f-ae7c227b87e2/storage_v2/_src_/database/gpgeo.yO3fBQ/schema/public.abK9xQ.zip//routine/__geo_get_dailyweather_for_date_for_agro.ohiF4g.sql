create function __geo_get_dailyweather_for_date_for_agro(agroid_ integer, date_ date)
    returns TABLE("WeatherGroup_id" integer, "WeatherData_datetime" text, "WeatherData_temperature" real, "WeatherData_dewpoint" real, "WeatherData_barometer" real, "WeatherData_rain" real, "WeatherGroup_name" character varying)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
	select  wg.id as "WeatherGroup_id",
			to_char(wd.datetime, 'YYYY-MM-DD HH24:MI:SS') as "WeatherData_datetime",		
			wd.temperature as "WeatherData_temperature",
			wd.dewpoint as "WeatherData_dewpoint",
			wd.barometer as "WeatherData_barometer",		
			wd.rain as "WeatherData_rain",
			wg.shortname as "WeatherGroup_name"

	from "WeatherData" as wd inner join 
			("WeatherStation" ws inner join 
				("WeatherGroup" wg inner join "WeatherGroupAgro" wga on (wg.id = wga.weathergroupid and wga.agroid = agroid_)) 
			on ws.weathergroupid = wg.id) 
		 on wd.weatherstationid = ws.id                         
					   	
	where DATE(wd.datetime AT TIME ZONE 'EAT') = date_
	order by wg.id, wd.datetime;
END;
$$;

alter function __geo_get_dailyweather_for_date_for_agro(integer, date) owner to geoadmin;

