create function __geo_get_monthlyweather_for_year_for_agro(agroid_ integer, year_ integer, month_ integer)
    returns TABLE("WeatherData_weathergroupid" integer, "WeatherData_date" date, "WeatherData_temperature_avg" numeric, "WeatherData_temperature_min" real, "WeatherData_temperature_max" real, "WeatherData_rain" numeric, "WeatherGroup_name" character varying)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
		select  wg.id as "WeatherData_weathergroupid",
				DATE(wd.datetime) as "WeatherData_date", 	   
				round(avg(wd.temperature)::numeric, 1) as "WeatherData_temperature_avg",
				min(wd.temperature) as "WeatherData_temperature_min",
				max(wd.temperature) as "WeatherData_temperature_max",
				round(sum(wd.rain)::numeric, 1) as "WeatherData_rain",
				wg.shortname as "WeatherGroup_name"
		from "WeatherData" as wd 
				inner join ("WeatherStation" ws 
								inner join ("WeatherGroup" wg inner join "WeatherGroupAgro" wga on (wg.id = wga.weathergroupid AND wga.agroid = agroid_))
								on ws.weathergroupid = wg.id)
				on  (ws.id = wd.weatherstationid					
					AND EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_ 
					AND EXTRACT(MONTH FROM wd.datetime)::INTEGER = month_)	
		group by wg.id, wg.shortname, DATE(wd.datetime)
		order by wg.id, DATE(wd.datetime);
END;
$$;

alter function __geo_get_monthlyweather_for_year_for_agro(integer, integer, integer) owner to geoadmin;

