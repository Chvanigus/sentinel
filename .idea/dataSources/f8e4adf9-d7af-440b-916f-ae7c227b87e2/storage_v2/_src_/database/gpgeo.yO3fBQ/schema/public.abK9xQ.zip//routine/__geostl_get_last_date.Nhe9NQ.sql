create function __geostl_get_last_date(agroid_ integer) returns date
    language plpgsql
as
$$
BEGIN
	IF agroid_ IS NULL THEN	
		RETURN max(date) from "Layer";
	ELSE
		RETURN max(l.date) 
		from 
		"Layer" l WHERE l.agroid = agroid_;
	END IF;	
END;
$$;

alter function __geostl_get_last_date(integer) owner to geoadmin;

