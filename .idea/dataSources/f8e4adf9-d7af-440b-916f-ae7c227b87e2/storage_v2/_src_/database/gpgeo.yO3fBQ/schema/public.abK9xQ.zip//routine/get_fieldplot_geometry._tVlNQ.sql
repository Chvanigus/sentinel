create function get_fieldplot_geometry() returns geometry
    language plpgsql
as
$$   
BEGIN
   return row_to_json(fc) 
	 FROM (SELECT 'Feature' As type
		, ST_AsGeoJSON(fp.plotgeometry)::json As geometry
	   FROM public.fieldplot As fp) As fc;
END
$$;

alter function get_fieldplot_geometry() owner to geoadmin;

