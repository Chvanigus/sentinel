create function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) returns geometry
    immutable
    strict
    language sql
as
$$SELECT ST_Affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)$$;

comment on function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) is 'args: geomA, a, b, d, e, xoff, yoff - Applies a 3d affine transformation to the geometry to do things like translate, rotate, scale in one step.';

alter function st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) owner to postgres;

