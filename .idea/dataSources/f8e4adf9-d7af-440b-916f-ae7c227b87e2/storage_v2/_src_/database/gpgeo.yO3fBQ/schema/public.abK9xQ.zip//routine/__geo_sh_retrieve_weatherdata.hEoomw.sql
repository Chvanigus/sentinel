create function __geo_sh_retrieve_weatherdata(weatherstationid_ integer) returns void
    language plpgsql
as
$$
BEGIN 

INSERT INTO "WeatherData" 
	( unixtime
	 ,datetime
	 ,usunits
	 ,barometer
	 ,pressure
	 ,altimeter
	 ,intemp
	 ,temperature
	 ,inhumidity
	 ,humidity
	 ,windspeed
	 ,winddegrees
	 ,winddirection
	 ,windgust
	 ,windgustdegrees
	 ,rainrate
	 ,rain
	 ,dewpoint
	 ,windchill
	 ,heatindex
	 ,consbatteryvoltage
	 ,weatherstationid	 
	)
	
			SELECT  remotearchive.datetime AS "unixtime",	
					(to_timestamp(remotearchive.datetime) AT TIME ZONE 'Europe/Moscow') AS "datetime",
					remotearchive.usunits AS "usunits",
					round((remotearchive.barometer * 25.4)::numeric(10,2), 1) AS "barometer",
					round((remotearchive.pressure * 25.4)::numeric(10,2), 1) AS "pressure",
					round((remotearchive.altimeter * 25.4)::numeric(10,2), 1) AS "altimeter",
					round(((5.0/9.0)*(remotearchive.intemp - 32))::numeric(10,2), 1) AS "intemp",
					round(((5.0/9.0)*(remotearchive.outtemp - 32))::numeric(10,2), 1) AS "temperature",
					remotearchive.inhumidity AS "inhumidity", 
					remotearchive.outhumidity AS "humidity",
					round((remotearchive.windspeed * 0.44704)::numeric(10,2), 1) AS "windspeed", 
					remotearchive.winddir AS "winddegrees",
					(CASE 	
						WHEN  	remotearchive.winddir >= 0 AND remotearchive.winddir < 11 THEN 'N' 
						WHEN	remotearchive.winddir >= 349 AND remotearchive.winddir <= 360 THEN 'N' 
						WHEN  	remotearchive.winddir >= 11 AND remotearchive.winddir < 56 THEN 'NEE' 
						WHEN  	remotearchive.winddir >= 56 AND remotearchive.winddir < 78 THEN 'NE'
						WHEN  	remotearchive.winddir >= 78 AND remotearchive.winddir < 101 THEN 'E' 
						WHEN  	remotearchive.winddir >= 101 AND remotearchive.winddir < 128 THEN 'SEE' 
						WHEN  	remotearchive.winddir >= 128 AND remotearchive.winddir < 146 THEN 'SE' 
						WHEN  	remotearchive.winddir >= 146 AND remotearchive.winddir < 168 THEN 'SSE' 
						WHEN  	remotearchive.winddir >= 168 AND remotearchive.winddir < 191 THEN 'S' 
						WHEN  	remotearchive.winddir >= 191 AND remotearchive.winddir < 213 THEN 'SSW' 
						WHEN  	remotearchive.winddir >= 213 AND remotearchive.winddir < 236 THEN 'SW' 
						WHEN  	remotearchive.winddir >= 236 AND remotearchive.winddir < 258 THEN 'SWW' 
						WHEN  	remotearchive.winddir >= 258 AND remotearchive.winddir < 281 THEN 'W' 
						WHEN  	remotearchive.winddir >= 281 AND remotearchive.winddir < 303 THEN 'NWW' 
						WHEN  	remotearchive.winddir >= 303 AND remotearchive.winddir < 326 THEN 'NW' 
						WHEN  	remotearchive.winddir >= 326 AND remotearchive.winddir < 349 THEN 'NNW'				
					END) AS "winddirection",
					round((remotearchive.windgust * 0.44704)::numeric(10,2), 1) AS "windgust", 
					remotearchive.windgustdir AS "windgustdegrees",
					round((remotearchive.rainrate * 25.4)::numeric(10,2), 1) AS "rainrate",
					round((remotearchive.rain * 25.4)::numeric(10,2), 1) AS "rain",
					round(((5.0/9.0)*(remotearchive.dewpoint - 32))::numeric(10,2), 1) AS "dewpoint", 
					round(((5.0/9.0)*(remotearchive.windchill - 32))::numeric(10,2), 1) AS "windchill",
					round(((5.0/9.0)*(remotearchive.heatindex - 32))::numeric(10,2), 1) AS "heatindex",
					remotearchive.consbatteryvoltage AS "consbatteryvoltage",	
					weatherstationid_ AS "weatherstationid"

			FROM "WeatherData" AS wd RIGHT OUTER JOIN

			dblink('dbname=wviewDB port=5432 host='''|| (select host(ip) from "WeatherStation" where id = weatherstationid_) || ''' user=root password=rootmeteo',
			
				   'SELECT 
						datetime,					
						usunits,
						barometer,
						pressure,
						altimeter,
						intemp,
						outtemp,
						inhumidity, 
						outhumidity,
						windspeed, 
						winddir,					
						windgust, 
						windgustdir,
						rainrate,
						rain,
						dewpoint, 
						windchill,
						heatindex,
						consbatteryvoltage							
					FROM public.archive')
					
			AS remotearchive(
						datetime integer,						  
						usunits integer,
						barometer real,
						pressure real,
						altimeter real,
						intemp real,
						outtemp real,
						inhumidity real,
						outhumidity real,
						windspeed real,
						winddir real,						
						windgust real,
						windgustdir real,						  
						rainrate real,
						rain real,
						dewpoint real,
						windchill real,
					        heatindex real,			  
						consbatteryvoltage real)
						  
			ON remotearchive.datetime = wd.unixtime and wd.weatherstationid = weatherstationid_
			WHERE wd.unixtime IS NULL
			ORDER BY wd.unixtime;
			
EXCEPTION
	WHEN connection_exception THEN return; 
	WHEN connection_does_not_exist THEN return;
	WHEN connection_failure THEN return;
	WHEN sqlclient_unable_to_establish_sqlconnection THEN return;
	WHEN sqlserver_rejected_establishment_of_sqlconnection THEN return;
END;
$$;

alter function __geo_sh_retrieve_weatherdata(integer) owner to postgres;

