create function st_linestringfromwkb(bytea) returns geometry
    immutable
    strict
    language sql
as
$$
	SELECT CASE WHEN geometrytype(ST_GeomFromWKB($1)) = 'LINESTRING'
	THEN ST_GeomFromWKB($1)
	ELSE NULL END
	$$;

comment on function st_linestringfromwkb(bytea) is 'args: WKB - Makes a geometry from WKB with the given SRID.';

alter function st_linestringfromwkb(bytea) owner to postgres;

