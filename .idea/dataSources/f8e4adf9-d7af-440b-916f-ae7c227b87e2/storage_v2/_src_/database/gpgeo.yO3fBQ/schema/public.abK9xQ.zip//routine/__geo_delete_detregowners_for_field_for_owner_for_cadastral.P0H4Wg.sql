create function __geo_delete_detregowners_for_field_for_owner_for_cadastral(fieldid_ bigint, ownerid_ integer, cadastralid_ bigint) returns void
    language sql
as
$$
    DELETE from "DetachedRegionOwner" dro 
	WHERE 	dro.ownerid = ownerid_ AND
			dro.detachedregionid IN  
			(Select dr.id
			from  "DetachedRegion" dr inner join 	 
				  "FieldDetachedRegion" fdr on (dr.id = fdr.detachedregionid AND fdr.fieldid = fieldid_) 
									inner join
			      "Cadastral" c on (dr.cadastralid = c.id AND c.id = cadastralid_));
$$;

alter function __geo_delete_detregowners_for_field_for_owner_for_cadastral(bigint, integer, bigint) owner to postgres;

