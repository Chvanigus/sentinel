create function __geo_get_field_areacalc(agroid_ integer, year_ integer, fieldname_ character varying) returns double precision
    language plpgsql
as
$$   
BEGIN
	return round (cast (ST_Area(ST_Transform(fs.fieldgeometry, 32638)) / 10000 as numeric), 2) As "AreaCalc"		
	from 	"Field" f 
			inner join "FieldShape" fs 	
			on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_ AND f.name = fieldname_);
END
$$;

alter function __geo_get_field_areacalc(integer, integer, varchar) owner to postgres;

