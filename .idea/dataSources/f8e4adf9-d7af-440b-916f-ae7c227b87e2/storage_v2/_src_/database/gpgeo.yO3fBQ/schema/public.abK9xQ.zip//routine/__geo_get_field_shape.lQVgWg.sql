create function __geo_get_field_shape(agroid_ integer, year_ integer, fieldname_ character varying) returns json
    language plpgsql
as
$$   
BEGIN
   return 
			(CASE WHEN geometry is not null THEN row_to_json(ftc) 
											ELSE null
			END)
FROM (SELECT 'Feature' As type
		    , ST_AsGeoJSON(fs.fieldgeometry)::json As geometry				
		
	  FROM "FieldShape" fs inner join "Field" f on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_ AND f.name = fieldname_)) As ftc;

END
$$;

alter function __geo_get_field_shape(integer, integer, varchar) owner to postgres;

