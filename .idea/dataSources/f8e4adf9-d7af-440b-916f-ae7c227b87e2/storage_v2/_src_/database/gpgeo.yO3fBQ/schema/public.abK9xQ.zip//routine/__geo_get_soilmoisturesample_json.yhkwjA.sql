create function __geo_get_soilmoisturesample_json(agroid_ integer, year_ integer, monthfrom_ integer, monthto_ integer) returns json
    language plpgsql
as
$$ 
  
BEGIN
   return (CASE WHEN features is not null THEN row_to_json(ftc) 
										  ELSE null
		   END)
		   
FROM (SELECT 'FeatureCollection' As type, array_to_json(array_agg(ft)) As features
FROM (SELECT 'Feature' As type
	    , ff3.geometry
		, row_to_json(row(ff3.field, 
						ff3.centrx, 
						ff3.centry,
						ff3.area,
						ff3.date, 
						ff3.fillcolor, 
						ff3.textcolor,
						ff3.soilmoistures,
						ff3.fieldcrop
						)::"soilMoistureSampleJsonProp") as properties

from

(select 
	 ff2.field
	,to_char(ff2.date, 'DD.MM.YYYY') as date
	,ST_AsGeoJSON(ff2.geometry)::json as geometry
	,ST_X (ST_Centroid(ff2.geometry)) as centrx
	,ST_Y (ST_Centroid(ff2.geometry)) as centry
	,round (cast (ST_Area(ST_Transform(ff2.geometry, 32638)) / 10000 as numeric), 2) as area
	,'#' || st.fillcolor as fillcolor
	,'#' || st.textcolor as textcolor
		
	,(CASE WHEN ffc.fc is not null THEN row_to_json(ffc)
										ELSE null
	 END) as fieldcrop
	
	,ff2.soilmoistures

FROM		
		
(select 
	 rank()  OVER (PARTITION BY ff1.field order by ff1.smsid DESC) as rank_	
	
	,ff1.smsid
	,ff1.field
	,ff1.date
	,ff1.geometry
	,ff1.valueto
	,ff1.fieldcrop
		
	,ff1.soilmoistures
	
FROM	
	
	(select  
		 sms.id as smsid
		,f.name as field
		,sms.date as date
		,(CASE 	WHEN  smst9.number = 0 OR smst9.number = 1 
					OR smst8.number = 0 OR smst8.number = 1
						THEN 9 
				WHEN  smst7.number = 0 OR smst7.number = 1 
					OR smst6.number = 0 OR smst6.number = 1
						THEN 7 
				WHEN  smst5.number = 0 OR smst5.number = 1 
					OR smst4.number = 0 OR smst4.number = 1
						THEN 5
				WHEN  smst3.number = 0 OR smst3.number = 1 
					OR smst2.number = 0 OR smst2.number = 1
					OR smst1.number = 0 OR smst1.number = 1
					OR smst0.number = 0 OR smst0.number = 1
						THEN 3
						ELSE -1
		END) as valueto
					
	    ,(CASE WHEN fp.plotgeometry is not null THEN fp.plotgeometry 
												ELSE fs.fieldgeometry
		 END) as geometry
		 
		,(CASE WHEN fp.plotgeometry is not null THEN fp.id 
												ELSE -1
		 END) as plot
		 
		,(CASE WHEN sms.fieldcropid is not null THEN sms.fieldcropid 
												ELSE null
		 END) as fieldcrop
		 
		,row_to_json(row( 
			 smst0.name
			,smst1.name
			,smst2.name
			,smst3.name
			,smst4.name
			,smst5.name
			,smst6.name
			,smst7.name
			,smst8.name
			,smst9.name)::"soilMoistures") as "soilmoistures"
		
			
	from 	"SoilMoistureSample" sms
		inner join	"SoilMoistureState" smst0 on sms.layer010 = smst0.id
		inner join	"SoilMoistureState" smst1 on sms.layer1020 = smst1.id
		inner join	"SoilMoistureState" smst2 on sms.layer2030 = smst2.id
		inner join	"SoilMoistureState" smst3 on sms.layer3040 = smst3.id
		inner join	"SoilMoistureState" smst4 on sms.layer4050 = smst4.id
		inner join	"SoilMoistureState" smst5 on sms.layer5060 = smst5.id
		inner join	"SoilMoistureState" smst6 on sms.layer6070 = smst6.id
		inner join	"SoilMoistureState" smst7 on sms.layer7080 = smst7.id
		inner join	"SoilMoistureState" smst8 on sms.layer8090 = smst8.id
		inner join	"SoilMoistureState" smst9 on sms.layer90100 = smst9.id
		
		inner join ("Field" As f inner join "FieldShape" As fs on (f.id = fs.fieldid AND fs.year = year_ AND f.agroid = agroid_)) on (sms.fieldid = f.id)
		left outer join ("FieldCrop" As fc inner join "FieldPlot" As fp on (fp.id = fc.fieldplotid)) on (sms.fieldcropid = fc.id AND fc.yieldyear = year_)
		
	where  	EXTRACT(MONTH FROM sms.date)::INTEGER >= monthfrom_ 
			AND EXTRACT(MONTH FROM sms.date)::INTEGER <= monthto_ 
			AND EXTRACT(YEAR FROM sms.date)::INTEGER = year_
	) as ff1
) as ff2

inner join "Stile" st on (st.valueto = ff2.valueto AND st.name = 'SoilMoistureSample' AND ff2.rank_=1)

left outer join (
	select
		fc.id as fc
		,c.shortname as "Crop"
		,t.shortname as "Technology"
		,s.shortname as "Sort"
		,fc.accountcroparea as "AccountCropArea"
	
	from
		"FieldCrop" fc 
		inner join "Crop" c on fc.cropid = c.id
		left outer join "Technology" t on fc.technologyid = t.id
		left outer join "Sort" s on fc.sortid = s.id					
	) as ffc on (ffc.fc = ff2.fieldcrop)

) ff3

) as ft) As ftc;

END
$$;

alter function __geo_get_soilmoisturesample_json(integer, integer, integer, integer) owner to postgres;

