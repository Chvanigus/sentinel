create function __geo_insert_json_to_fieldplot(plotgeometry_ text) returns bigint
    language plpgsql
as
$$ 
	DECLARE
		fieldplot_id bigint;
	BEGIN
		INSERT INTO public."FieldPlot"(plotgeometry) VALUES (ST_GeomFromGeoJSON(plotgeometry_))
		RETURNING id into fieldplot_id;
		RETURN fieldplot_id;
	END;
$$;

alter function __geo_insert_json_to_fieldplot(text) owner to postgres;

