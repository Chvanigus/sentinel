create function __geo_delete_detachedregionowners_for_field_for_owner(fieldid_ bigint, ownerid_ integer) returns void
    language sql
as
$$
    DELETE from "DetachedRegionOwner" dro 
	WHERE 	dro.ownerid = ownerid_ AND
			dro.detachedregionid IN  
			(Select dr.id
			from "DetachedRegion" dr inner join 	 
				 "FieldDetachedRegion" fdr on (dr.id = fdr.detachedregionid AND fdr.fieldid = fieldid_));
$$;

alter function __geo_delete_detachedregionowners_for_field_for_owner(bigint, integer) owner to postgres;

