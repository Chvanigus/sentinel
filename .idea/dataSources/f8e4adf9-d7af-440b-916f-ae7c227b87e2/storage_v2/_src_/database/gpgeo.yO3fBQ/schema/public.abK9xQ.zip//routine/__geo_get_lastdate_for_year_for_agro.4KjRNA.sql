create function __geo_get_lastdate_for_year_for_agro(agroid_ integer, year_ integer) returns date
    language sql
as
$$  
	select  MAX(DATE(wd.datetime))
	from "WeatherData" as wd 
			inner join ("WeatherStation" ws  
				inner join "WeatherGroupAgro" wga on (wga.weathergroupid = ws.weathergroupid and wga.agroid = agroid_) )
		    on wd.weatherstationid = ws.id
	where EXTRACT(YEAR FROM wd.datetime)::INTEGER = year_;	
$$;

alter function __geo_get_lastdate_for_year_for_agro(integer, integer) owner to geoadmin;

