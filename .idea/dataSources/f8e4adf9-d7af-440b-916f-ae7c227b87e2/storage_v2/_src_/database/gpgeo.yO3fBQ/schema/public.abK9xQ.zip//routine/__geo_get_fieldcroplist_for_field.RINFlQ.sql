create function __geo_get_fieldcroplist_for_field(fieldid_ bigint)
    returns TABLE("FieldCrop_id" bigint, "FieldCrop_yieldyear" smallint, "FieldCrop_accountcroparea" real, "FieldCrop_yieldfact" real, "Crop_name" character varying, "Technology_name" character varying, delete boolean, plotnumber bigint)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
	
		select	 fc.id as "FieldCrop_id"
				,fc.yieldyear as "FieldCrop_yieldyear"
				,fc.accountcroparea as "FieldCrop_accountcroparea"
				,fc.yieldfact as "FieldCrop_yieldfact"
				,c.name as "Crop_name"
				,t.name as "Technology_name"
				,(CASE 	WHEN rank () Over (partition by fc.yieldyear order by fc.id) = 1 THEN false
					ELSE true
				  END) as "delete"
				,count (*) Over (partition by fc.yieldyear) as "plotnumber"
		from 	"FieldCrop" fc	
				inner join "Crop" c on c.id = fc.cropid
				left outer join "Technology" t on t.id = fc.technologyid			
		where   	fc.fieldid = fieldid_
		order by fc.yieldyear DESC, fc.startdate DESC;
END;
$$;

alter function __geo_get_fieldcroplist_for_field(bigint) owner to geoadmin;

