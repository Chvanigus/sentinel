create function st_force_collection(geometry) returns geometry
    immutable
    strict
    language sql
as
$$ SELECT _postgis_deprecate('ST_Force_Collection', 'ST_ForceCollection', '2.1.0');
    SELECT ST_ForceCollection($1);
  $$;

alter function st_force_collection(geometry) owner to postgres;

