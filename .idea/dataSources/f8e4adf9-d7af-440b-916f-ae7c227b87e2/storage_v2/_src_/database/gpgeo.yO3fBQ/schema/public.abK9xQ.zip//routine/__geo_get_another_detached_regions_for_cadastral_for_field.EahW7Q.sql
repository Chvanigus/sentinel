create function __geo_get_another_detached_regions_for_cadastral_for_field(fieldid_ bigint, cadastralid_ bigint)
    returns TABLE("DetachedRegion_id" bigint, "DetachedRegion_number" character varying, "DetachedRegion_area" real, "DetachedRegion_officialarea" real, "DetachedRegion_sharenumerator" real, "DetachedRegion_sharedenominator" real)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY   
	select
		dr.id as "DetachedRegion_id",
		dr.number as "DetachedRegion_number",
		dr.area as "DetachedRegion_area",
		dr.officialarea as "DetachedRegion_officialarea",
		dr.sharenumerator as "DetachedRegion_sharenumerator",
		dr.sharedenominator as "DetachedRegion_sharedenominator"
	from "Cadastral" c inner join 
		("DetachedRegion" dr inner join "FieldDetachedRegion" fdr on (dr.id = fdr.detachedregionid AND dr.id NOT IN (SELECT dr2.id FROM "DetachedRegion" dr2 inner join "FieldDetachedRegion" AS fdr2 on (dr2.id = fdr2.detachedregionid AND fdr2.fieldid = fieldid_)))) 
		on (dr.cadastralid = c.id AND c.id = cadastralid_)
	group by dr.id
	order by dr.number;
END;
$$;

alter function __geo_get_another_detached_regions_for_cadastral_for_field(bigint, bigint) owner to postgres;

