create function __geoutil_get_field_bounds(agroid_ integer, year_ integer, fieldgroupid_ integer)
    returns TABLE(xmin double precision, ymin double precision, xmax double precision, ymax double precision)
    language plpgsql
as
$$  
BEGIN

   IF fieldgroupid_ IS NULL THEN
   RETURN QUERY 
		SELECT ST_XMin(s.geom), ST_YMin(s.geom), ST_XMax(s.geom), ST_YMax(s.geom)
   FROM
		( SELECT ST_Extent(ST_Transform(fs.fieldgeometry, 3857)) as geom
			FROM "FieldShape" fs INNER JOIN "Field" f ON (fs.fieldid = f.id AND f.agroid = agroid_ AND fs.year = year_)
		) s;
		
   ELSE
   RETURN QUERY 
		SELECT ST_XMin(s.geom), ST_YMin(s.geom), ST_XMax(s.geom), ST_YMax(s.geom)
   FROM
		( SELECT ST_Extent(ST_Transform(fs.fieldgeometry, 3857)) as geom
			FROM "FieldShape" fs INNER JOIN 
				("Field" f INNER JOIN "FieldFieldGroup" ffg ON (f.id = ffg.fieldid AND ffg.fieldgroupid = fieldgroupid_ AND ffg.year = year_)) 
				ON (fs.fieldid = f.id AND f.agroid = agroid_ AND fs.year = year_)
		) s;
END IF;	
END;
$$;

alter function __geoutil_get_field_bounds(integer, integer, integer) owner to geoadmin;

