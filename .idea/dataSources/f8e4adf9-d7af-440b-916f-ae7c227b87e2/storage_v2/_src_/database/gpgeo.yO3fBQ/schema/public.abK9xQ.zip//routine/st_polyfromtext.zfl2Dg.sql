create function st_polyfromtext(text) returns geometry
    immutable
    strict
    language sql
as
$$
	SELECT CASE WHEN geometrytype(ST_GeomFromText($1)) = 'POLYGON'
	THEN ST_GeomFromText($1)
	ELSE NULL END
	$$;

alter function st_polyfromtext(text) owner to postgres;

