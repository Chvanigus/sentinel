create function __geo_get_detachedregions_for_field_for_owner_for_cadastral(fieldid_ bigint, ownerid_ integer, cadastralid_ bigint)
    returns TABLE("DetachedRegion_id" bigint, "DetachedRegion_number" character varying, "DetachedRegion_area" real)
    language plpgsql
as
$$
BEGIN
	if ownerid_ = -1 then
		RETURN QUERY
		SELECT  dr.id as "DetachedRegion_id",
				dr.number as "DetachedRegion_number",
				dr.area as "DetachedRegion_area"		
		From "DetachedRegion" dr inner join "FieldDetachedRegion" fdr on dr.id = fdr.detachedregionid And fdr.fieldid = fieldid_
		where dr.cadastralid = cadastralid_	
		ORDER BY dr.number;
	else
		RETURN QUERY
		SELECT  dr.id as "DetachedRegion_id",
				dr.number as "DetachedRegion_number",
				dr.area as "DetachedRegion_area"		
		From "DetachedRegion" dr inner join "FieldDetachedRegion" fdr on dr.id = fdr.detachedregionid And fdr.fieldid = fieldid_
						   left outer join "DetachedRegionOwner" dro on (dr.id = dro.detachedregionid And dro.ownerid = ownerid_)
		where dr.cadastralid = cadastralid_ And dro.detachedregionid is null	
		ORDER BY dr.number;
	end if;
END;
$$;

alter function __geo_get_detachedregions_for_field_for_owner_for_cadastral(bigint, integer, bigint) owner to postgres;

