create function __geo_get_fieldsweather(agroid_ bigint, year_ integer)
    returns TABLE("FieldWeatherData_id" bigint, "FieldWeatherData_date" text, "FieldWeatherData_temperaturemax" real, "FieldWeatherData_temperaturemin" real, "FieldWeatherData_temperaturemean" real, "FieldWeatherData_dailyrain" real, "FieldWeatherData_additional" text, "Fields" json)
    language plpgsql
as
$$
BEGIN
	RETURN QUERY 
	select	 fwd.id as "FieldWeatherData_id"
			,to_char(fwd.date, 'DD.MM.YYYY') as "FieldWeatherData_date"
			,fwd.temperaturemax as "FieldWeatherData_temperaturemax"
			,fwd.temperaturemin as "FieldWeatherData_temperaturemin"
			,fwd.temperaturemean as "FieldWeatherData_temperaturemean"
			,fwd.dailyrain as "FieldWeatherData_dailyrain"
			,fwd.additional as "FieldWeatherData_additional"
			,array_to_json(array_agg(json_build_object('id', f.id, 'name', f.name))) as "Fields"
			
	from 	"FieldWeatherData" fwd		
			inner join ("FieldWeatherDataField" fwdf inner join "Field" f on (fwdf.fieldid = f.id AND f.agroid = agroid_))
			on fwd.id = fwdf.fieldweatherdataid
	where  EXTRACT(YEAR FROM fwd.date)::INTEGER = year_

	group by fwd.id, fwd.date, fwd.temperaturemax, fwd.temperaturemin, fwd.temperaturemean, fwd.dailyrain, fwd.additional 
	order by "FieldWeatherData_date" DESC; 
END;
$$;

alter function __geo_get_fieldsweather(bigint, integer) owner to postgres;

